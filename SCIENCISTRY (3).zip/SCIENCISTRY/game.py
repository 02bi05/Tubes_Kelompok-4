import sys
from PyQt5.QtWidgets import *
from PyQt5 import QtGui, QtCore
from PyQt5.QtGui import QCursor
from pertanyaan import pertanyaan
from PyQt5.QtGui import QPixmap
from PyQt5.QtMultimedia import *
import pertanyaan_3

grid = QGridLayout()
score = 0

#Menghapus Layer Sebelumnya
def clear_widgets():
    for widget in widgets:
        if widgets[widget] != []:
            widgets[widget][-1].hide()
        for i in range(0, len(widgets[widget])):
            widgets[widget].pop()

#Tampilan Main Menu
def load():
    clear_widgets()
    frame1()
def start_game():
    clear_widgets()
    frame2()

# Menampilkan Pilihan Level Matematika
def show_frame3():
    clear_widgets()
    pilihan_level_matematika()



# Menampilkan Soal
def show_soal1_level1_matematika():
    clear_widgets()
    soal1_level1_matematika()
def show_soal2_level1_matematika():
    clear_widgets()
    soal2_level1_matematika()

def show_soal3_level1_matematika():
    clear_widgets()
    soal3_level1_matematika()

# Menampilkan Benar atau Salah
def show_correct1():
    clear_widgets()
    correct_1()

def show_correct2():
    clear_widgets()
    correct_2()

def show_correct3():
    clear_widgets()
    correct_3()

def show_wrong1():
    clear_widgets()
    wrong_1()

def show_wrong2():
    clear_widgets()
    wrong_2()

def show_wrong3():
    clear_widgets()
    wrong_3()

def keluar2():
    clear_widgets()
    pergi()

# Menampilkan Tampilan Akhir
def akhir():
    clear_widgets()
    tampilan_akhir()

# Untuk Keluar dari Aplikasi
def quit():
    QApplication.quit()


#Aplikasi masih dalam proses pengembangan
def belum_berfungsi():
    bf = QLabel("Maaf, saat ini prgram masih dalam pengembangan.")
    bf.setAlignment(QtCore.Qt.AlignCenter)
    bf.setWordWrap(True)
    bf.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )

    back = create_button("Kembali")
    widgets["Kembali"].append(back)
    grid.addWidget(widgets["Kembali"][-1], 2, 0, 1, 1)
    back.clicked.connect(start_game)
    widgets["bf"].append(bf)
    grid.addWidget(widgets["bf"][-1], 0, 0, 1, 2)

# Aplikasi masih dalam pengembangan
def test():
    clear_widgets()
    belum_berfungsi()

# Kembali ke Frame Sebelumnya

widgets = {
    "button": [],
    "mode": [],
    "mode1": [],
    "mode2": [],
    "mode3": [],
    "mode4": [],
    "level": [],
    "level1": [],
    "level2": [],
    "level3": [],
    "level4": [],
    "keluar": [],
    "pilihan1": [],
    "pilihan2": [],
    "bf": [],
    "Kembali": [],
    "pesan_akhir": [],
    "pesan_akhir_2": [],
    "soal": [],
    "ceklist": []
}
# Tombol, baik untuk menjawab ataupun untuk yang lainnya
def create_button(answer):
    button = QPushButton(answer)
    button.setCursor(QCursor(QtCore.Qt.PointingHandCursor))
    button.setFixedWidth(485)
    button.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    return button

def frame1():
    button = QPushButton("Tekan di area berikut untuk memulai")
    button.setCursor(QCursor(QtCore.Qt.PointingHandCursor))
    button.setFixedWidth(1500)
    button.setFixedHeight(400)
    button.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
        )
    button.clicked.connect(start_game)
    widgets["button"].append(button)

    grid.addWidget(widgets["button"][-1], 0, 0)

#---------------------
  # Main Menu (Mode)
#---------------------
def frame2():
    mode = QLabel("Pilih Subjek yang Diinginkan")
    mode.setAlignment(QtCore.Qt.AlignCenter)
    mode.setWordWrap(True)
    mode.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
        )
    widgets["mode"].append(mode)
    grid.addWidget(widgets["mode"][-1], 0, 0, 1, 2)

    mode1 = create_button("Matematika")
    mode2 = create_button("Quit")

    widgets["mode1"].append(mode1)
    widgets["mode2"].append(mode2)

    grid.addWidget(widgets["mode1"][-1], 2, 0)
    grid.addWidget(widgets["mode2"][-1], 2, 1)

    mode1.clicked.connect(show_frame3)
    mode2.clicked.connect(keluar2)

# Fitur Pilihan Level
def pilihan_level_matematika():
    level = QLabel("Pilih Level yang Diinginkan")
    level.setAlignment(QtCore.Qt.AlignCenter)
    level.setWordWrap(True)
    level.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["level"].append(level)
    grid.addWidget(widgets["level"][-1], 0, 0, 1, 2)

    level1 = create_button("1")
    level2 = create_button("2")
    level3 = create_button("3")
    level4 = create_button("4")

    widgets["level1"].append(level1)
    widgets["level2"].append(level2)
    widgets["level3"].append(level3)
    widgets["level4"].append(level4)

    grid.addWidget(widgets["level1"][-1], 2, 0)
    grid.addWidget(widgets["level2"][-1], 2, 1)
    grid.addWidget(widgets["level3"][-1], 3, 0)
    grid.addWidget(widgets["level4"][-1], 3, 1)

    level1.clicked.connect(show_soal1_level1_matematika)
    level2.clicked.connect(test)
    level3.clicked.connect(test)
    level4.clicked.connect(test)

# Fitur Keluar dari Program
def pergi():
    tampilan_keluar = QLabel("Apakah Anda ingin Keluar?")
    tampilan_keluar.setAlignment(QtCore.Qt.AlignCenter)
    tampilan_keluar.setWordWrap(True)
    tampilan_keluar.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["keluar"].append(tampilan_keluar)
    grid.addWidget(widgets["keluar"][-1], 0, 0, 1, 2)

    pil_1 = create_button("Ya")
    pil_2 = create_button("Tidak")

    widgets["pilihan1"].append(pil_1)
    widgets["pilihan2"].append(pil_2)

    grid.addWidget(widgets["pilihan1"][-1], 1, 0)
    grid.addWidget(widgets["pilihan2"][-1], 1, 1)

    pil_1.clicked.connect(quit)
    pil_2.clicked.connect(start_game)

def soal1_level1_matematika():
    soal1 = QLabel("Sebuah lapangan berbentuk lingkaran dengan diameter 70 m. \nDisekeliling lapangan akan dipasang bendera dengan jarak 5 meter. \nBerapa banyak bendera yang dibutuhkan...")
    soal1.setAlignment(QtCore.Qt.AlignCenter)
    soal1.setWordWrap(True)
    soal1.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["soal"].append(soal1)
    grid.addWidget(widgets["soal"][-1], 0, 0, 1, 2)

    level1 = create_button("28")
    level2 = create_button("36")
    level3 = create_button("44")
    level4 = create_button("49")

    widgets["level1"].append(level1)
    widgets["level2"].append(level2)
    widgets["level3"].append(level3)
    widgets["level4"].append(level4)

    grid.addWidget(widgets["level1"][-1], 2, 0)
    grid.addWidget(widgets["level2"][-1], 2, 1)
    grid.addWidget(widgets["level3"][-1], 3, 0)
    grid.addWidget(widgets["level4"][-1], 3, 1)

    level1.clicked.connect(show_wrong1)
    level2.clicked.connect(show_wrong1)
    level3.clicked.connect(show_correct1)
    level4.clicked.connect(show_wrong1)

def soal2_level1_matematika():
    soal2 = QLabel("Sebuah taman berbentuk persegi. Di sekeliling taman itu ditanami \npohon pinus dengan jarak antar pohon 5 m. Panjang sisi taman itu adalah 100 m. \nBanyak pohon pinus yang dibutuhkan adalah")
    soal2.setAlignment(QtCore.Qt.AlignCenter)
    soal2.setWordWrap(True)
    soal2.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["soal"].append(soal2)
    grid.addWidget(widgets["soal"][-1], 0, 0, 1, 2)

    level1 = create_button("80")
    level2 = create_button("90")
    level3 = create_button("70")
    level4 = create_button("60")

    widgets["level1"].append(level1)
    widgets["level2"].append(level2)
    widgets["level3"].append(level3)
    widgets["level4"].append(level4)

    grid.addWidget(widgets["level1"][-1], 2, 0)
    grid.addWidget(widgets["level2"][-1], 2, 1)
    grid.addWidget(widgets["level3"][-1], 3, 0)
    grid.addWidget(widgets["level4"][-1], 3, 1)

    level1.clicked.connect(show_correct2)
    level2.clicked.connect(show_wrong2)
    level3.clicked.connect(show_wrong2)
    level4.clicked.connect(show_wrong2)

def soal3_level1_matematika():
    soal3 = QLabel("Sebuah lingkaran mempunyai jari-jari 49 cm. Hitunglah berapa keliling dari lingkaran tersebut…")
    soal3.setAlignment(QtCore.Qt.AlignCenter)
    soal3.setWordWrap(True)
    soal3.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["soal"].append(soal3)
    grid.addWidget(widgets["soal"][-1], 0, 0, 1, 2)

    level1 = create_button("256")
    level2 = create_button("269")
    level3 = create_button("294")
    level4 = create_button("308")

    widgets["level1"].append(level1)
    widgets["level2"].append(level2)
    widgets["level3"].append(level3)
    widgets["level4"].append(level4)

    grid.addWidget(widgets["level1"][-1], 2, 0)
    grid.addWidget(widgets["level2"][-1], 2, 1)
    grid.addWidget(widgets["level3"][-1], 3, 0)
    grid.addWidget(widgets["level4"][-1], 3, 1)

    level1.clicked.connect(show_wrong3)
    level2.clicked.connect(show_wrong3)
    level3.clicked.connect(show_wrong3)
    level4.clicked.connect(show_correct3)

# Jawaban Benar
def correct_1():
    ceklist = QLabel("Jawaban Anda Benar! \nPembahasan: ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)

    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(show_soal2_level1_matematika)


# Jawaban Salah
def correct_2():
    ceklist = QLabel("Jawaban Anda Benar! \nPembahasan: ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)

    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(show_soal3_level1_matematika)


def correct_3():
    ceklist = QLabel("Jawaban Anda Benar! \nPembahasan: ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)

    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(akhir)



def wrong_1():
    ceklist = QLabel("Jawaban Anda Salah!! \nPembahasan ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)
    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(soal2_level1_matematika)

def wrong_2():
    ceklist = QLabel("Jawaban Anda Salah!! \nPembahasan ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)
    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(show_soal3_level1_matematika)

def wrong_3():
    ceklist = QLabel("Jawaban Anda Salah!! \nPembahasan ")
    ceklist.setAlignment(QtCore.Qt.AlignCenter)
    ceklist.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["ceklist"].append(ceklist)
    grid.addWidget(widgets["ceklist"][-1], 0, 0, 1, 2)
    pil_1 = create_button("Lanjut")
    widgets["pilihan1"].append(pil_1)
    grid.addWidget(widgets["pilihan1"][-1], 0, 0, 2, 2)
    pil_1.clicked.connect(akhir)

# Tampilan Akhir
def tampilan_akhir():
    pesan_akhir =  QLabel("Skor Akhir: ")
    pesan_akhir.setAlignment(QtCore.Qt.AlignCenter)
    pesan_akhir.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["pesan_akhir"].append(pesan_akhir)
    grid.addWidget(widgets["pesan_akhir"][-1], 0, 0, 0, 2)

    pesan_akhir_2 = QLabel("Apakah Anda ingin Lanjut?")
    pesan_akhir_2.setAlignment(QtCore.Qt.AlignCenter)
    pesan_akhir_2.setStyleSheet(
        "font-family: Cambria Math;"
        "color: 'white'"
    )
    widgets["pesan_akhir_2"].append(pesan_akhir_2)
    grid.addWidget(widgets["pesan_akhir_2"][-1], 0, 0, 1, 2)

    pil_1 = create_button("Ya")
    pil_2 = create_button("Tidak")

    widgets["pilihan1"].append(pil_1)
    widgets["pilihan2"].append(pil_2)

    grid.addWidget(widgets["pilihan1"][-1], 1, 0)
    grid.addWidget(widgets["pilihan2"][-1], 1, 1)

    pil_1.clicked.connect(show_frame3)
    pil_2.clicked.connect(start_game)









